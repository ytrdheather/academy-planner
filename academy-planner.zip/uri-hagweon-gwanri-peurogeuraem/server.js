import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import session from 'express-session';
import path from 'path';
import { fileURLToPath } from 'url';
import { getUncachableNotionClient } from './notion-client.js';

// getAccessToken 함수 추가 (notion-client.js에서 가져오기)
async function getAccessToken() {
  const hostname = process.env.REPLIT_CONNECTORS_HOSTNAME
  const xReplitToken = process.env.REPL_IDENTITY 
    ? 'repl ' + process.env.REPL_IDENTITY 
    : process.env.WEB_REPL_RENEWAL 
    ? 'depl ' + process.env.WEB_REPL_RENEWAL 
    : null;

  if (!xReplitToken) {
    throw new Error('X_REPLIT_TOKEN not found for repl/depl');
  }

  const connectionSettings = await fetch(
    'https://' + hostname + '/api/v2/connection?include_secrets=true&connector_names=notion',
    {
      headers: {
        'Accept': 'application/json',
        'X_REPLIT_TOKEN': xReplitToken
      }
    }
  ).then(res => res.json()).then(data => data.items?.[0]);

  const accessToken = connectionSettings?.settings?.access_token || connectionSettings.settings?.oauth?.credentials?.access_token;

  if (!connectionSettings || !accessToken) {
    throw new Error('Notion not connected');
  }
  return accessToken;
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 5000;

// 미들웨어 설정
app.use(cors({
  origin: process.env.NODE_ENV === 'production' ? false : 'http://localhost:5000',
  credentials: true
}));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.use('/assets', express.static('assets'));
app.use(session({
  secret: process.env.SESSION_SECRET || 'readitude-secret-key-change-in-production',
  resave: false,
  saveUninitialized: false,
  cookie: { 
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 24 * 60 * 60 * 1000 // 24시간
  }
}));

// 환경 변수 검증 (필수)
const requiredEnvVars = {
  STUDENT_DATABASE_ID: '학생 로그인 정보 데이터베이스',
  PROGRESS_DATABASE_ID: '학습 진도 데이터베이스',
  TEACHER_ACCESS_TOKEN: '선생님 접근 토큰'
};

const missingVars = Object.keys(requiredEnvVars).filter(key => !process.env[key]);
if (missingVars.length > 0 && process.env.NODE_ENV === 'production') {
  console.error('❌ 프로덕션 환경에서 필수 환경 변수가 설정되지 않았습니다:');
  missingVars.forEach(key => {
    console.error(`   ${key}: ${requiredEnvVars[key]}`);
  });
  console.error('   이 변수들을 설정한 후 서버를 다시 시작하세요.');
  process.exit(1);
} else if (missingVars.length > 0) {
  console.warn('⚠️  개발 환경: 일부 환경 변수가 설정되지 않았습니다 (기본값 사용):');
  missingVars.forEach(key => {
    console.warn(`   ${key}: ${requiredEnvVars[key]}`);
  });
}

// 데이터베이스 ID를 Notion 형식으로 변환하는 함수
function formatNotionId(id) {
  // 대시가 없는 경우 Notion 형식으로 변환 (8-4-4-4-12)
  if (id && !id.includes('-') && id.length === 32) {
    return `${id.substring(0, 8)}-${id.substring(8, 12)}-${id.substring(12, 16)}-${id.substring(16, 20)}-${id.substring(20, 32)}`;
  }
  return id;
}

// 학생 데이터베이스 ID (원생 관리)  
const STUDENT_DB_ID = formatNotionId(process.env.STUDENT_DATABASE_ID || '25409320bce280f8ace1ddcdd022b360');
const PROGRESS_DB_ID = formatNotionId(process.env.PROGRESS_DATABASE_ID || '25409320bce2807697ede3f1c1b62ada');
const BOOK_LIST_DB_ID = formatNotionId(process.env.BOOK_LIST_DATABASE_ID || '9ef2bbaeec19466daa0d0c0677b9eb90');
const SAYU_BOOK_DB_ID = formatNotionId(process.env.SAYU_BOOK_DATABASE_ID || 'cf82d56634574d7e83d893fbf1b1a4e3');



// 데이터베이스 연결 확인 완료


// 사유독평 책 제목 자동완성 API (3독 독서용)
app.get('/api/search-sayu-books', async (req, res) => {
  const { query } = req.query;
  
  try {
    if (!query || query.length < 2) {
      return res.json([]);
    }
    
    const accessToken = await getAccessToken();
    
    // 사유독평 합본 리스트에서 검색
    const response = await fetch(`https://api.notion.com/v1/databases/${SAYU_BOOK_DB_ID}/query`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
        'Notion-Version': '2022-06-28'
      },
      body: JSON.stringify({
        filter: {
          property: '3독 요약 사유독평 도서 보유 목록',
          title: {
            contains: query
          }
        },
        sorts: [
          {
            property: '3독 요약 사유독평 도서 보유 목록',
            direction: 'ascending'
          }
        ],
        page_size: 10
      })
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error('사유독평 도서 검색 API 상세 오류:', errorText);
      throw new Error(`사유독평 도서 검색 실패: ${response.status} - ${errorText}`);
    }
    
    const data = await response.json();
    
    const books = data.results.map(page => {
      const title = page.properties['3독 요약 사유독평 도서 보유 목록']?.title?.[0]?.plain_text || '';
      const author = page.properties[' 지은이']?.rich_text?.[0]?.plain_text || '';
      const publisher = page.properties[' 출판사']?.rich_text?.[0]?.plain_text || '';
      
      return {
        title,
        author,
        publisher,
        display: author ? `${title} (${author})` : title
      };
    }).filter(book => book.title && book.title.toLowerCase().includes(query.toLowerCase()));
    
    res.json(books);
  } catch (error) {
    console.error('사유독평 책 검색 오류:', error);
    res.status(500).json({ error: '책 검색 중 오류가 발생했습니다.' });
  }
});

// 영어 원서 제목 자동완성 API
app.get('/api/search-books', async (req, res) => {
  const { query } = req.query;
  
  try {
    if (!query || query.length < 2) {
      return res.json([]);
    }
    
    const accessToken = await getAccessToken();
    
    // 리디튜드 영통 도서리스트에서 검색
    const response = await fetch(`https://api.notion.com/v1/databases/${BOOK_LIST_DB_ID}/query`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
        'Notion-Version': '2022-06-28'
      },
      body: JSON.stringify({
        filter: {
          property: 'Title',
          title: {
            contains: query
          }
        },
        sorts: [
          {
            property: 'Title',
            direction: 'ascending'
          }
        ],
        page_size: 10
      })
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error('도서 검색 API 상세 오류:', errorText);
      throw new Error(`도서 검색 실패: ${response.status} - ${errorText}`);
    }
    
    const data = await response.json();
    const books = data.results.map(page => {
      const title = page.properties.Title?.title?.[0]?.plain_text || '';
      const level = page.properties.Level?.select?.name || '';
      const series = page.properties.Series?.rich_text?.[0]?.plain_text || '';
      
      return {
        title,
        level,
        series,
        display: level ? `${title} (${level})` : title
      };
    }).filter(book => book.title && book.title.toLowerCase().includes(query.toLowerCase())); // 클라이언트 사이드에서도 한번 더 필터링
    
    res.json(books);
    
  } catch (error) {
    console.error('책 검색 오류:', error);
    res.status(500).json({ error: '책 검색 중 오류가 발생했습니다.' });
  }
});

// 로그인 페이지
app.get('/', (req, res) => {
  if (req.session.studentId) {
    return res.redirect('/planner');
  }
  res.sendFile(path.join(__dirname, 'views', 'login.html'));
});

// 학습 플래너 페이지
app.get('/planner', (req, res) => {
  if (!req.session.studentId) {
    return res.redirect('/');
  }
  res.sendFile(path.join(__dirname, 'views', 'planner.html'));
});

// 세션에서 학생 정보 가져오기 API
app.get('/api/student-info', (req, res) => {
  if (!req.session.studentId) {
    return res.status(401).json({ error: '로그인이 필요합니다' });
  }
  
  res.json({
    studentId: req.session.studentId,
    studentName: req.session.studentName || req.session.studentId,
    studentRealName: req.session.studentRealName || req.session.studentName || req.session.studentId
  });
});

// 선생님 페이지
// 선생님 로그인 페이지
app.get('/teacher-login', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'teacher-login.html'));
});

// 다중 사용자 계정 설정
const userAccounts = {
  // 매니저 (전체 관리)
  'manager': { password: 'rdtd112!@', role: 'manager', name: '매니저', assignedStudents: 'all' },
  
  // 선생님 4명 (담당 학생만)
  'teacher1': { password: 'rdtd112!@', role: 'teacher', name: '선생님1', assignedStudents: [] },
  'teacher2': { password: 'rdtd112!@', role: 'teacher', name: '선생님2', assignedStudents: [] },
  'teacher3': { password: 'rdtd112!@', role: 'teacher', name: '선생님3', assignedStudents: [] },
  'teacher4': { password: 'rdtd112!@', role: 'teacher', name: '선생님4', assignedStudents: [] },
  
  // 아르바이트생 2명 (제한적 권한)
  'assistant1': { password: 'rdtd112!@', role: 'assistant', name: '아르바이트1', assignedStudents: [] },
  'assistant2': { password: 'rdtd112!@', role: 'assistant', name: '아르바이트2', assignedStudents: [] }
};

// 선생님 로그인 처리
app.post('/teacher-login', async (req, res) => {
  const { teacherId, teacherPassword } = req.body;
  
  // 사용자 계정 확인
  const userAccount = userAccounts[teacherId];
  
  if (userAccount && teacherPassword === userAccount.password) {
    // 보안: 세션 고정 공격 방지를 위한 세션 ID 재생성
    req.session.regenerate((err) => {
      if (err) {
        console.error('세션 재생성 오류:', err);
        return res.json({ success: false, message: '로그인 처리 중 오류가 발생했습니다.' });
      }
      
      // 세션에 사용자 정보 저장
      req.session.isTeacher = true;
      req.session.userId = teacherId;
      req.session.userRole = userAccount.role;
      req.session.userName = userAccount.name;
      req.session.assignedStudents = userAccount.assignedStudents;
      
      console.log(`로그인 성공: ${userAccount.name} (${userAccount.role})`);
      
      // 세션 저장 후 응답
      req.session.save((err) => {
        if (err) {
          console.error('세션 저장 오류:', err);
          return res.json({ success: false, message: '로그인 처리 중 오류가 발생했습니다.' });
        }
        res.json({ success: true, message: '로그인 성공' });
      });
    });
  } else {
    console.log(`로그인 실패: ${teacherId}`);
    res.json({ success: false, message: '아이디 또는 비밀번호가 올바르지 않습니다.' });
  }
});

// 선생님 로그아웃
app.post('/teacher-logout', (req, res) => {
  // 보안: 완전한 세션 파기 및 쿠키 삭제
  req.session.destroy((err) => {
    if (err) {
      console.error('세션 파기 오류:', err);
      return res.json({ success: false, message: '로그아웃 처리 중 오류가 발생했습니다.' });
    }
    
    // 세션 쿠키 삭제
    res.clearCookie('connect.sid'); // 기본 세션 쿠키 이름
    res.json({ success: true, message: '로그아웃 되었습니다.' });
  });
});

// 선생님 대시보드 (세션 확인 필요)
app.get('/teacher', (req, res) => {
  if (!req.session.isTeacher) {
    return res.redirect('/teacher-login');
  }
  res.sendFile(path.join(__dirname, 'views', 'teacher.html'));
});

// 로그인 처리
app.post('/login', async (req, res) => {
  const { studentId, password } = req.body;
  
  try {
    // 학생 정보 조회 - REST API 직접 호출
    const accessToken = await getAccessToken();
    
    const restResponse = await fetch(`https://api.notion.com/v1/databases/${STUDENT_DB_ID}/query`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
        'Notion-Version': '2022-06-28'
      },
      body: JSON.stringify({
        filter: {
          and: [
            {
              property: '학생 ID',
              rich_text: {
                equals: studentId
              }
            },
            {
              property: '비밀번호',
              rich_text: {
                equals: password.toString()
              }
            }
          ]
        }
      })
    });
    
    if (!restResponse.ok) {
      const errorText = await restResponse.text();
      console.error('로그인 API 오류:', errorText);
      throw new Error(`로그인 API 호출 실패: ${restResponse.status}`);
    }
    
    const response = await restResponse.json();

    if (response.results.length > 0) {
      req.session.studentId = studentId;
      
      // 학생 데이터베이스의 모든 필드 확인 (디버깅용)
      console.log('학생 데이터베이스 필드들:', Object.keys(response.results[0].properties));
      
      // 실제 이름 필드 찾기 ('이름', 'Name', '학생이름' 등 시도)
      const studentRecord = response.results[0].properties;
      let realName = null;
      
      // 가능한 이름 필드들 시도
      const nameFields = ['이름', 'Name', '학생이름', '학생 이름', '성명'];
      for (const field of nameFields) {
        if (studentRecord[field]?.rich_text?.[0]?.plain_text) {
          realName = studentRecord[field].rich_text[0].plain_text;
          console.log(`찾은 이름 필드: ${field} = ${realName}`);
          break;
        }
        if (studentRecord[field]?.title?.[0]?.plain_text) {
          realName = studentRecord[field].title[0].plain_text;
          console.log(`찾은 이름 필드 (title): ${field} = ${realName}`);
          break;
        }
      }
      
      req.session.studentName = realName || studentId;
      req.session.studentRealName = realName; // 실제 이름 별도 저장
      console.log('세션에 저장된 학생 이름:', req.session.studentName);
      
      res.json({ success: true, message: '로그인 성공!' });
    } else {
      res.json({ success: false, message: '아이디 또는 비밀번호가 올바르지 않습니다.' });
    }
  } catch (error) {
    console.error('로그인 오류:', error);
    res.json({ success: false, message: '로그인 중 오류가 발생했습니다.' });
  }
});

// 로그아웃
app.post('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/');
});

// 학습 데이터 저장
app.post('/save-progress', async (req, res) => {
  console.log('=== 저장 요청 시작 ===');
  console.log('세션 학생 ID:', req.session.studentId);
  console.log('받은 폼 데이터:', JSON.stringify(req.body, null, 2));
  
  if (!req.session.studentId) {
    return res.json({ success: false, message: '로그인이 필요합니다.' });
  }

  try {
    console.log('액세스 토큰 획득 중...');
    const accessToken = await getAccessToken();
    console.log('액세스 토큰 획득 완료');
    
    const formData = req.body;
    
    // 오늘 날짜로 새 항목 생성
    const today = new Date().toISOString().split('T')[0];
    
    // 학생 정보부터 찾기 - relation 필드를 위해 학생의 실제 페이지 ID 필요
    console.log('학생 페이지 ID 찾는 중... 학생 ID:', req.session.studentId);
    
    // REST API로 학생 데이터베이스에서 이 학생의 페이지 ID 찾기
    const studentResponse = await fetch(`https://api.notion.com/v1/databases/${STUDENT_DB_ID}/query`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
        'Notion-Version': '2022-06-28'
      },
      body: JSON.stringify({
        filter: {
          property: '학생 ID',
          rich_text: {
            equals: req.session.studentId
          }
        }
      })
    });
    
    if (!studentResponse.ok) {
      throw new Error(`학생 정보 조회 실패: ${studentResponse.status}`);
    }
    
    const studentData = await studentResponse.json();
    
    if (studentData.results.length === 0) {
      throw new Error(`학생 ID ${req.session.studentId}를 찾을 수 없습니다.`);
    }
    
    const studentPageId = studentData.results[0].id;
    console.log('찾은 학생 페이지 ID:', studentPageId);
    
    // 오늘 날짜에 해당하는 기존 일지 찾기 (MAKE가 아침에 생성한 껍데기 일지)
    console.log('오늘 날짜의 기존 일지 찾는 중...');
    const existingLogResponse = await fetch(`https://api.notion.com/v1/databases/${PROGRESS_DB_ID}/query`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
        'Notion-Version': '2022-06-28'
      },
      body: JSON.stringify({
        filter: {
          and: [
            {
              property: '🕐 날짜',
              date: {
                equals: today
              }
            },
            {
              property: '학생 명부 관리',
              relation: {
                contains: studentPageId
              }
            }
          ]
        }
      })
    });
    
    if (!existingLogResponse.ok) {
      throw new Error(`기존 일지 조회 실패: ${existingLogResponse.status}`);
    }
    
    const existingLogData = await existingLogResponse.json();
    
    if (existingLogData.results.length === 0) {
      throw new Error(`오늘 날짜(${today})의 기존 일지를 찾을 수 없습니다. MAKE 자동화가 실행되었는지 확인해주세요.`);
    }
    
    const existingPageId = existingLogData.results[0].id;
    console.log('찾은 기존 일지 페이지 ID:', existingPageId);
    
    // 업데이트할 properties (날짜와 학생 관계는 이미 설정되어 있으므로 제외)
    const properties = {};

    // 숙제 확인 필드들 (상태 속성) - "해당없음"은 저장하지 않음
    if (formData['⭕ 지난 문법 숙제 검사'] && formData['⭕ 지난 문법 숙제 검사'] !== '해당없음') {
      properties['⭕ 지난 문법 숙제 검사'] = { status: { name: formData['⭕ 지난 문법 숙제 검사'] } };
    }
    if (formData['1️⃣ 어휘 클카 암기 숙제'] && formData['1️⃣ 어휘 클카 암기 숙제'] !== '해당없음') {
      properties['1️⃣ 어휘 클카 암기 숙제'] = { status: { name: formData['1️⃣ 어휘 클카 암기 숙제'] } };
    }
    if (formData['2️⃣ 독해 단어 클카 숙제'] && formData['2️⃣ 독해 단어 클카 숙제'] !== '해당없음') {
      properties['2️⃣ 독해 단어 클카 숙제'] = { status: { name: formData['2️⃣ 독해 단어 클카 숙제'] } };
    }
    if (formData['4️⃣ Summary 숙제'] && formData['4️⃣ Summary 숙제'] !== '해당없음') {
      properties['4️⃣ Summary 숙제'] = { status: { name: formData['4️⃣ Summary 숙제'] } };
    }
    if (formData['5️⃣ 매일 독해 숙제'] && formData['5️⃣ 매일 독해 숙제'] !== '해당없음') {
      properties['5️⃣ 매일 독해 숙제'] = { status: { name: formData['5️⃣ 매일 독해 숙제'] } };
    }
    if (formData['6️⃣ 영어 일기(초등) / 개인 독해서 (중고등)'] && formData['6️⃣ 영어 일기(초등) / 개인 독해서 (중고등)'] !== '해당없음') {
      properties['6️⃣ 영어 일기(초등) / 개인 독해서 (중고등)'] = { status: { name: formData['6️⃣ 영어 일기(초등) / 개인 독해서 (중고등)'] } };
    }

    // 폼 데이터를 Notion 속성으로 변환
    if (formData['어휘정답']) {
      properties['어휘정답'] = { number: parseInt(formData['어휘정답']) || 0 };
    }
    if (formData['어휘총문제']) {
      properties['어휘총문제'] = { number: parseInt(formData['어휘총문제']) || 0 };
    }
    if (formData['어휘유닛']) {
      properties['어휘유닛'] = { rich_text: [{ text: { content: formData['어휘유닛'] } }] };
    }
    if (formData['문법 전체 개수']) {
      properties['문법 전체 개수'] = { number: parseInt(formData['문법 전체 개수']) || 0 };
    }
    if (formData['문법숙제오답']) {
      properties['문법숙제오답'] = { number: parseInt(formData['문법숙제오답']) || 0 };
    }
    if (formData['독해오답갯수']) {
      properties['독해오답갯수'] = { number: parseInt(formData['독해오답갯수']) || 0 };
    }
    if (formData['독해하브루타']) {
      properties['독해하브'] = { select: { name: formData['독해하브루타'] } };
    }
    if (formData['영어 더빙 학습 완료']) {
      properties['영어 더빙 학습 완료'] = { status: { name: formData['영어 더빙 학습 완료'] } };
    }
    if (formData['더빙 워크북 완료']) {
      properties['더빙 워크북 완료'] = { status: { name: formData['더빙 워크북 완료'] } };
    }
    if (formData['📖 영어독서']) {
      properties['📖 영어독서'] = { select: { name: formData['📖 영어독서'] } };
    }
    if (formData['어휘학습']) {
      properties['어휘학습'] = { select: { name: formData['어휘학습'] } };
    }
    if (formData['Writing']) {
      properties['Writing'] = { select: { name: formData['Writing'] } };
    }
    // 영어 책 relation 연결 (오늘 읽은 영어 책)
    if (formData['오늘 읽은 영어 책']) {
      console.log('영어 책 검색 중:', formData['오늘 읽은 영어 책']);
      
      // 영어 책 데이터베이스에서 해당 책 찾기
      const englishBookResponse = await fetch(`https://api.notion.com/v1/databases/${BOOK_LIST_DB_ID}/query`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
          'Notion-Version': '2022-06-28'
        },
        body: JSON.stringify({
          filter: {
            property: 'Title',
            title: {
              equals: formData['오늘 읽은 영어 책']
            }
          }
        })
      });
      
      if (englishBookResponse.ok) {
        const englishBookData = await englishBookResponse.json();
        if (englishBookData.results.length > 0) {
          const bookPageId = englishBookData.results[0].id;
          console.log('찾은 영어 책 페이지 ID:', bookPageId);
          properties['오늘 읽은 영어 책'] = { relation: [{ id: bookPageId }] };
        } else {
          console.log('영어 책을 찾을 수 없음:', formData['오늘 읽은 영어 책']);
        }
      }
    }
    
    // 3독 독서 제목 relation 연결
    if (formData['3독 독서 제목']) {
      console.log('3독 독서 책 검색 중:', formData['3독 독서 제목']);
      
      // 사유독평 책 데이터베이스에서 해당 책 찾기
      const sayuBookResponse = await fetch(`https://api.notion.com/v1/databases/${SAYU_BOOK_DB_ID}/query`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
          'Notion-Version': '2022-06-28'
        },
        body: JSON.stringify({
          filter: {
            property: '3독 요약 사유독평 도서 보유 목록',
            title: {
              equals: formData['3독 독서 제목']
            }
          }
        })
      });
      
      if (sayuBookResponse.ok) {
        const sayuBookData = await sayuBookResponse.json();
        if (sayuBookData.results.length > 0) {
          const bookPageId = sayuBookData.results[0].id;
          console.log('찾은 3독 독서 책 페이지 ID:', bookPageId);
          properties['3독 독서 제목'] = { relation: [{ id: bookPageId }] };
        } else {
          console.log('3독 독서 책을 찾을 수 없음:', formData['3독 독서 제목']);
        }
      }
    }
    
    if (formData['📕 책 읽는 거인']) {
      properties['📕 책 읽는 거인'] = { select: { name: formData['📕 책 읽는 거인'] } };
    }
    if (formData['오늘의 학습 소감']) {
      properties['오늘의 학습 소감'] = { rich_text: [{ text: { content: formData['오늘의 학습 소감'] } }] };
    }

    console.log('최종 업데이트 properties 객체:', JSON.stringify(properties, null, 2));
    console.log('업데이트할 기존 일지 ID:', existingPageId);
    
    // REST API로 기존 Notion 페이지 업데이트
    console.log('Notion 페이지 업데이트 API 호출 중...');
    const updateResponse = await fetch(`https://api.notion.com/v1/pages/${existingPageId}`, {
      method: 'PATCH',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
        'Notion-Version': '2022-06-28'
      },
      body: JSON.stringify({
        properties: properties
      })
    });
    
    if (!updateResponse.ok) {
      const errorText = await updateResponse.text();
      console.error('페이지 업데이트 실패 상세:', errorText);
      throw new Error(`페이지 업데이트 실패: ${updateResponse.status} - ${errorText}`);
    }
    
    const result = await updateResponse.json();
    console.log('업데이트 성공! 기존 일지 ID:', result.id);
    res.json({ success: true, message: '학습 데이터가 성공적으로 저장되었습니다!' });
  } catch (error) {
    console.error('=== 저장 오류 발생 ===');
    console.error('오류 메시지:', error.message);
    console.error('오류 스택:', error.stack);
    if (error.body) {
      console.error('Notion API 오류 상세:', JSON.stringify(error.body, null, 2));
    }
    res.json({ success: false, message: '저장 중 오류가 발생했습니다: ' + error.message });
  }
});

// 선생님 API 인증 미들웨어 (세션 기반만 허용)
function requireTeacherAuth(req, res, next) {
  // 세션 확인
  if (req.session && req.session.isTeacher) {
    return next();
  }
  
  // 보안: 프로덕션에서는 세션 기반 인증만 허용
  // 개발 환경에서만 토큰 기반 허용 (보안 강화)
  if (process.env.NODE_ENV !== 'production') {
    const authHeader = req.headers.authorization;
    const validToken = process.env.TEACHER_ACCESS_TOKEN;
    
    if (validToken && authHeader === `Bearer ${validToken}`) {
      return next();
    }
  }
  
  return res.status(401).json({ 
    error: '선생님 인증이 필요합니다. 로그인해주세요.',
    redirect: '/teacher-login'
  });
}

// 전체 학생 진도 조회 (선생님용)
app.get('/api/student-progress', requireTeacherAuth, async (req, res) => {
  try {
    console.log('선생님 진도 조회 시작...');
    const notion = await getUncachableNotionClient();
    console.log('Notion 클라이언트 타입:', typeof notion, notion && notion.constructor && notion.constructor.name);
    
    // Notion 클라이언트가 제대로 생성되었는지 확인
    if (!notion || typeof notion.databases?.query !== 'function') {
      console.error('Notion 클라이언트가 올바르지 않음:', notion);
      // 임시 데이터 반환하여 대시보드 테스트 가능하게 함
      return res.json([
        {
          id: 'temp1',
          studentId: 'Test 원장',
          date: '2025-09-24',
          vocabScore: 85,
          grammarScore: 90,
          readingResult: 'pass',
          englishReading: '완료함',
          bookTitle: 'Harry Potter',
          feeling: '오늘 영어 공부가 재미있었어요!'
        },
        {
          id: 'temp2',
          studentId: 'Test 원장',
          date: '2025-09-23',
          vocabScore: 78,
          grammarScore: 82,
          readingResult: 'pass',
          englishReading: '완료함',
          bookTitle: 'Charlotte\'s Web',
          feeling: '단어가 조금 어려웠지만 열심히 했어요.'
        }
      ]);
    }

    const response = await notion.databases.query({
      database_id: PROGRESS_DB_ID,
      sorts: [
        {
          property: '날짜',
          direction: 'descending'
        }
      ]
    });

    const progressData = response.results.map(page => {
      const props = page.properties;
      return {
        id: page.id,
        studentId: props['학생 ID']?.rich_text?.[0]?.plain_text || '',
        date: props['날짜']?.date?.start || '',
        vocabScore: props['📰 단어 테스트 점수']?.formula?.number || 0,
        grammarScore: props['📑 문법 시험 점수']?.formula?.number || 0,
        readingResult: props['📚 독해 해석 시험 결과']?.formula?.string || '',
        englishReading: props['📖 영어독서']?.select?.name || '',
        bookTitle: props['오늘 읽은 영어 책']?.rich_text?.[0]?.plain_text || '',
        feeling: props['오늘의 학습 소감']?.rich_text?.[0]?.plain_text || ''
      };
    });

    // 권한별 데이터 필터링
    const filteredData = filterStudentsByRole(userRole, assignedStudents, progressData);
    
    // 활동 로그 기록
    console.log(`${userName}(${userRole})이 ${filteredData.length}건의 진도 데이터를 조회했습니다.`);
    
    res.json(filteredData);
  } catch (error) {
    console.error('전체 진도 조회 오류:', error);
    // 에러 발생시에도 권한별 임시 데이터 반환
    const errorSampleData = [
      {
        id: 'temp1',
        studentId: 'Test 원장',
        date: '2025-09-25',
        vocabScore: 85,
        grammarScore: 90,
        readingResult: 'pass',
        englishReading: '완료함',
        bookTitle: 'Harry Potter',
        feeling: '오늘 영어 공부가 재미있었어요!',
        assignedTeacher: '선생님1'
      }
    ];
    res.json(filterStudentsByRole(userRole, assignedStudents, errorSampleData));
  }
});

// 특정 학생 진도 조회 (선생님용)
app.get('/api/student-progress/:studentId', requireTeacherAuth, async (req, res) => {
  try {
    const notion = await getUncachableNotionClient();
    const { studentId } = req.params;
    
    const response = await notion.databases.query({
      database_id: PROGRESS_DB_ID,
      filter: {
        property: '학생 ID',
        rich_text: {
          equals: studentId
        }
      },
      sorts: [
        {
          property: '날짜',
          direction: 'descending'
        }
      ]
    });

    const progressData = response.results.map(page => {
      const props = page.properties;
      return {
        id: page.id,
        studentId: props['학생 ID']?.rich_text?.[0]?.plain_text || '',
        date: props['날짜']?.date?.start || '',
        vocabScore: props['📰 단어 테스트 점수']?.formula?.number || 0,
        grammarScore: props['📑 문법 시험 점수']?.formula?.number || 0,
        readingResult: props['📚 독해 해석 시험 결과']?.formula?.string || '',
        englishReading: props['📖 영어독서']?.select?.name || '',
        bookTitle: props['오늘 읽은 영어 책']?.rich_text?.[0]?.plain_text || '',
        feeling: props['오늘의 학습 소감']?.rich_text?.[0]?.plain_text || ''
      };
    });

    res.json(progressData);
  } catch (error) {
    console.error('특정 학생 진도 조회 오류:', error);
    res.json({ error: '진도 조회 중 오류가 발생했습니다.' });
  }
});

// 서버 시작
app.listen(PORT, '0.0.0.0', async () => {
  console.log(`🚀 학습 플래너 서버가 포트 ${PORT}에서 실행 중입니다!`);
  console.log(`📝 학생용: http://localhost:${PORT}`);
  console.log(`👩‍🏫 선생님용: http://localhost:${PORT}/teacher`);
  
  // Notion 연결 상태 확인
  try {
    console.log('🔗 Notion 연결 상태를 확인중...');
    const notion = await getUncachableNotionClient();
    console.log('✅ Notion 연결 성공!');
    
  } catch (error) {
    console.error('❌ Notion 연결 실패:', error.message);
    console.log('💡 해결 방법: Replit의 Secrets에서 Notion 연결을 확인해주세요');
  }
});